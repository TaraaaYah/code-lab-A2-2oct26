# Tara-Yah Weather – Data Driven App (CodeLab II)

An interactive openFrameworks (C++) GUI app that fetches live weather data from the WeatherAPI.com API.

## Features
- City search plus favourite city buttons (Manchester, Salford, London)
- Current weather: temperature, feels like, humidity, wind, pressure, UV, visibility, cloud cover, air quality
- 3-day forecast cards with chance of rain
- Weather condition icon downloaded from the API
- Options: Celsius/Fahrenheit, mph/km/h, dark/light theme, show/hide air quality and forecast
- Auto refresh with adjustable interval
- Error handling for empty input, unknown city, invalid API key and no connection

## How to run
1. Open this folder with the openFrameworks Project Generator (addon: ofxGui) and click Update/Generate.
2. Open the .sln file in Visual Studio.
3. Press F5 to build and run.

## Files
- `src/main.cpp` – sets up the 1600x1000 window
- `src/ofApp.h` – class, variables and GUI controls
- `src/ofApp.cpp` – API request, JSON parsing and drawing
